CHARMS AND CLAWS — GitHub Pages

Upload all files in this folder to a GitHub repository named:
Iqrome786-gif.github.io

Then enable:
Settings → Pages → Deploy from a branch → main → /(root) → Save

Your site address will be:
https://iqrome786-gif.github.io/
